# RhymeSphere Mock Server (GitHub-ready)

This repository contains a FastAPI mock server for RhymeSphere with rich dummy data.
It is ready to deploy to Railway (or Render) via GitHub integration.

## Files
- `mock_server/main.py` - FastAPI app implementing endpoints under `/api/v1/`
- `openapi.yaml` - OpenAPI spec (same API served by the mock server)
- `requirements.txt` - Python dependencies
- `Procfile` - For Railway/Heroku-style deploy
- `Dockerfile` - Optional Docker image build
- `README.md` - this file

## Deploy to Railway (quick)
1. Create a new GitHub repo and push this project.
2. In Railway, choose **Deploy → GitHub Repo** and select your repo.
3. Railway will detect Python and install dependencies from `requirements.txt`.
4. App will be exposed at a public URL like `https://your-app.up.railway.app`.
5. Swagger docs: `https://your-app.up.railway.app/api/v1/docs`

## Local run
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python mock_server/main.py
```
