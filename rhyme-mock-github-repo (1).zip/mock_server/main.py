from fastapi import FastAPI, HTTPException, Query, Path, Body
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
import uvicorn
import uuid

app = FastAPI(title="RhymeSphere Mock API", version="1.0.0", openapi_url="/api/v1/openapi.json", docs_url="/api/v1/docs")

# -- Rich dummy data --
users = [
    {"id":"u1","email":"ali@example.com","displayName":"Ali","region":"PK","role":"user","createdAt":"2024-12-01T10:00:00Z"},
    {"id":"u2","email":"sara@example.com","displayName":"Sara","region":"IN","role":"user","createdAt":"2025-01-15T09:30:00Z"},
    {"id":"u3","email":"john@example.com","displayName":"John","region":"UK","role":"user","createdAt":"2025-03-20T08:00:00Z"},
    {"id":"admin","email":"muhammadyt6150@gmail.com","displayName":"Admin","region":"PK","role":"admin","createdAt":"2025-07-01T00:00:00Z"}
]

poems = [
    {"id":"p1","title":"محبت کی شام","author":"Ali","authorId":"u1","language":"ur-PK","status":"approved","tags":["love","ghazal"],"body":"یہ دل تری یاد میں کھو گیا","createdAt":"2025-08-01T12:00:00Z"},
    {"id":"p2","title":"City Nights","author":"John","authorId":"u3","language":"en-GB","status":"approved","tags":["urban","night"],"body":"City lights, whispering streets","createdAt":"2025-08-05T20:00:00Z"},
    {"id":"p3","title":"صبح کا نغمہ","author":"Sara","authorId":"u2","language":"ur-IN","status":"pending","tags":["morning","ghazal"],"body":"نئی صبح کا پیغام ہے","createdAt":"2025-09-01T06:00:00Z"}
]

comments = [
    {"id":"c1","poemId":"p1","userId":"u2","text":"بہت خوب!","timestamp":"2025-09-01T12:30:00Z"},
    {"id":"c2","poemId":"p1","userId":"u3","text":"Amazing imagery.","timestamp":"2025-09-02T08:20:00Z"}
]

reports = [
    {"id":"r1","poemId":"p3","reportedBy":"u3","reason":"Possible plagiarism","status":"pending","createdAt":"2025-09-03T10:00:00Z"}
]

analytics = {
    "totalUsers": 1200,
    "totalPoems": 250,
    "totalTranslations": 800,
    "totalTTS": 450,
    "byRegion": {"PK": 700, "IN": 350, "UK": 150}
}

trending = [
    {"id":"p1","title":"محبت کی شام","author":"Ali","score":95,"region":"PK"},
    {"id":"p2","title":"City Nights","author":"John","score":88,"region":"UK"}
]

# -- Pydantic models --
class AuthReq(BaseModel):
    email: str
    password: str

class AuthResp(BaseModel):
    accessToken: str
    refreshToken: str
    role: str

class PoemCreate(BaseModel):
    title: str
    body: str
    authorId: str
    language: str
    tags: Optional[List[str]] = []
    scheduledAt: Optional[datetime] = None

class TranslateReq(BaseModel):
    text: str
    source: str
    target: str
    preserveRhyme: Optional[bool] = False
    tone: Optional[str] = None

class TranslateResp(BaseModel):
    translated: str
    transliteration: Optional[str] = None
    meta: Optional[dict] = {}

class TTSReq(BaseModel):
    text: str
    lang: str
    voice: Optional[str] = None
    poemId: Optional[str] = None
    backgroundMusic: Optional[str] = None

class AnalyticsEvent(BaseModel):
    type: str
    poemId: Optional[str] = None
    userId: Optional[str] = None
    region: Optional[str] = None
    device: Optional[str] = None
    timestamp: datetime

# -- Auth endpoints --
@app.post("/api/v1/auth/login", response_model=AuthResp)
def login(req: AuthReq):
    # very simple mock auth: if matches admin credentials return admin role
    if req.email == "muhammadyt6150@gmail.com" and req.password == "9045CcF2.@.":
        return {"accessToken":"mock-admin-token","refreshToken":"mock-refresh","role":"admin"}
    # fallback: if email exists, return user token
    for u in users:
        if u["email"] == req.email:
            return {"accessToken":"mock-user-token","refreshToken":"mock-refresh","role":"user"}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.post("/api/v1/auth/refresh")
def refresh(body: dict = Body(...)):
    return {"accessToken":"mock-access-token","refreshToken":"mock-refresh"}

# -- Poems --
@app.get("/api/v1/poems")
def list_poems(page: int = Query(1), pageSize: int = Query(20), region: Optional[str] = None, lang: Optional[str]=None, query: Optional[str]=None):
    # simple filter by lang or region (author's region)
    results = poems
    if lang:
        results = [p for p in results if p.get("language","").startswith(lang)]
    if query:
        q = query.lower()
        results = [p for p in results if q in p.get("title","").lower() or q in p.get("body","").lower()]
    start = (page-1)*pageSize
    return results[start:start+pageSize]

@app.post("/api/v1/poems", status_code=201)
def upload_poem(p: PoemCreate):
    new = p.dict()
    new_id = "p" + str(len(poems)+1) + "-" + uuid.uuid4().hex[:6]
    new_entry = {
        "id": new_id,
        "title": new["title"],
        "body": new["body"],
        "authorId": new["authorId"],
        "author": next((u['displayName'] for u in users if u['id']==new['authorId']), "Unknown"),
        "language": new["language"],
        "tags": new.get("tags", []),
        "status": "pending",
        "createdAt": datetime.utcnow().isoformat() + "Z"
    }
    poems.append(new_entry)
    analytics["totalPoems"] += 1
    return {"id": new_id}

@app.get("/api/v1/poems/{id}")
def poem_detail(id: str = Path(...)):
    for p in poems:
        if p["id"] == id:
            # attach translations & audio mock
            p_detail = dict(p)
            p_detail["translations"] = [
                {"lang":"en","translated":"[EN] " + p.get("body",""), "updatedAt": (datetime.utcnow()-timedelta(days=1)).isoformat()+"Z"}
            ]
            p_detail["audio"] = [
                {"lang":"ur","voice":"male_ur_pk_1","url":"https://example.com/audio/" + p["id"] + ".mp3"}
            ]
            return p_detail
    raise HTTPException(status_code=404, detail="Not found")

@app.put("/api/v1/poems/{id}")
def poem_update(id: str, body: dict = Body(...)):
    for p in poems:
        if p["id"] == id:
            p.update(body)
            p["updatedAt"] = datetime.utcnow().isoformat() + "Z"
            return p
    raise HTTPException(status_code=404, detail="Not found")

@app.delete("/api/v1/poems/{id}", status_code=204)
def poem_delete(id: str = Path(...)):
    global poems
    poems = [p for p in poems if p["id"] != id]
    analytics["totalPoems"] = max(0, analytics["totalPoems"]-1)
    return {}

# -- Comments --
@app.get("/api/v1/poems/{id}/comments")
def poem_comments(id: str):
    return [c for c in comments if c["poemId"] == id]

@app.post("/api/v1/poems/{id}/comments", status_code=201)
def add_comment(id: str, body: dict = Body(...)):
    new_id = "c" + str(len(comments)+1)
    comment = {"id": new_id, "poemId": id, "userId": body.get("userId","u1"), "text": body.get("text",""), "timestamp": datetime.utcnow().isoformat()+"Z"}
    comments.append(comment)
    return {"id": new_id}

# -- Reports (moderation) --
@app.get("/api/v1/admin/reports")
def list_reports():
    return reports

@app.post("/api/v1/admin/reports", status_code=201)
def create_report(body: dict = Body(...)):
    new_id = "r" + str(len(reports)+1)
    report = {"id": new_id, "poemId": body.get("poemId"), "reportedBy": body.get("reportedBy"), "reason": body.get("reason"), "status":"pending", "createdAt": datetime.utcnow().isoformat()+"Z"}
    reports.append(report)
    return {"id": new_id}

# -- Translation & TTS endpoints (mock logic) --
@app.post("/api/v1/translate", response_model=TranslateResp)
def translate(req: TranslateReq):
    translated = req.text[::-1]
    translit = req.text.replace(" ", "-")
    return {"translated": translated, "transliteration": translit, "meta": {"model":"mock-v1"}}

@app.post("/api/v1/translate/batch", status_code=202)
def translate_batch(req: TranslateReq):
    return {"jobId":"tj-" + uuid.uuid4().hex[:8]}

@app.get("/api/v1/translate/job/{jobId}")
def translate_job(jobId: str):
    return {"jobId": jobId, "status":"done", "result":{"translated":"mock","transliteration":"mock"}}

@app.post("/api/v1/tts/generate", status_code=202)
def tts_generate(req: TTSReq):
    return {"jobId":"tts-" + uuid.uuid4().hex[:8]}

@app.get("/api/v1/tts/job/{jobId}")
def tts_job(jobId: str):
    return {"jobId": jobId, "status":"done", "audioUrl":"https://example.com/audio/" + jobId + ".mp3"}

# -- Analytics --
@app.post("/api/v1/analytics/event", status_code=202)
def analytics_event(evt: AnalyticsEvent):
    # increment counters for demo
    if evt.type == "tts_play":
        analytics["totalTTS"] += 1
    elif evt.type == "view":
        analytics["totalPoems"] += 0
    return {"status":"accepted"}

@app.get("/api/v1/analytics/poem/{id}")
def analytics_poem(id: str):
    return {"views": 120 + len([c for c in comments if c["poemId"]==id]), "likes": 10, "shares": 2}

@app.get("/api/v1/poems/trending")
def poems_trending(region: Optional[str] = None, period: Optional[str] = "24h", limit: int = 20):
    if region:
        return [t for t in trending if t["region"]==region][:limit]
    return trending[:limit]

# -- Admin endpoints --
@app.get("/api/v1/admin/analytics")
def admin_analytics():
    return analytics

@app.get("/api/v1/admin/poems")
def admin_poems():
    return poems

@app.post("/api/v1/admin/approve-poem")
def admin_approve(id: str = Query(...)):
    for p in poems:
        if p["id"] == id:
            p["status"] = "approved"
            return {"status":"approved"}
    raise HTTPException(status_code=404, detail="Not found")

@app.post("/api/v1/admin/reject-poem")
def admin_reject(id: str = Query(...), reason: Optional[str] = None):
    for p in poems:
        if p["id"] == id:
            p["status"] = "rejected"
            p["rejectionReason"] = reason
            return {"status":"rejected"}
    raise HTTPException(status_code=404, detail="Not found")

@app.delete("/api/v1/admin/poem/{id}", status_code=204)
def admin_delete(id: str = Path(...)):
    global poems
    poems = [p for p in poems if p["id"] != id]
    return {}

@app.get("/api/v1/admin/trending")
def admin_trending():
    return trending

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
